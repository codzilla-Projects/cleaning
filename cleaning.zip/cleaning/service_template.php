<div class="modal fade text-right services-popup" id="services-popup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div dir="rtl" class="modal-body services">
                <div class="booking-form">
                    <div class="form-heading">
                        <h2 class="text-center">حجز خدمة </h2>
                    </div>
                    
                    <?php echo do_shortcode('[contact-form-7 id="233" title="reserve service" html_id="ajax_appointment" html_class="form-horizontal"]'); ?>
                </div>           
	        </div>
        </div>
    </div>
</div>